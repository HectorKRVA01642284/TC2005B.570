import { useState } from "react";
import { Button, TextField, Box, Typography } from "@mui/material";
import { useNavigate } from "react-router-dom";

export default function Login({ setIsAuthenticated }) {
  const [user, setUser] = useState("");
  const [pass, setPass] = useState("");
  const navigate = useNavigate();

  const handleLogin = () => {
    if (user === "admin" && pass === "1234") {
      setIsAuthenticated(true); 
      navigate("/dashboard");  
    } else {
      alert("Credenciales incorrectas");
    }
  };

  return (
    <Box
  sx={{
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    mt: 5,
  }}
>
  <Box
    sx={{
      p: 4,
      borderRadius: 2,
      backgroundColor: "#000000", // 👈 gris claro (puedes poner "#fff" o cualquier color)
      boxShadow: 3,
      width: "300px",
      textAlign: "center",
    }}
  >
    <Typography variant="h5" sx={{ mb: 2 }}>
      Iniciar Sesión
    </Typography>

    <TextField
      fullWidth
      label="Usuario (escribir admin en este caso)"
      variant="outlined"
      sx={{ mb: 2, backgroundColor: "#fff", borderRadius: 1 }}
      onChange={(e) => setUser(e.target.value)}
    />
    <TextField
      fullWidth
      label="Contraseña (escribir 1234)"
      type="password"
      variant="outlined"
      sx={{ mb: 2, backgroundColor: "#fff", borderRadius: 1 }}
      onChange={(e) => setPass(e.target.value)}
    />
    <Button fullWidth variant="contained" onClick={handleLogin}>
      Entrar
    </Button>
  </Box>
</Box>

  );
}
