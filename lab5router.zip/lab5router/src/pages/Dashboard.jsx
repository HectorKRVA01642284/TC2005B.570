import { Typography, Box } from "@mui/material";

export default function Dashboard() {
  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4">Dashboard</Typography>
      <Typography>Aqui se podrian ver los datos principales (si tan solo hubiera xd).</Typography>
    </Box>
  );
}
