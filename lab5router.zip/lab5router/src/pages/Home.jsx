import { Typography, Box } from "@mui/material";

export default function Home() {
  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4">Bienvenido a la Homepage</Typography>
      <Typography>Esta es la página principal no es mucho pero es trabajo honesto :/.</Typography>
    </Box>
  );
}
