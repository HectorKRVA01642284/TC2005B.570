import { Typography, Box } from "@mui/material";

export default function Reports() {
  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4">Reports</Typography>
      <Typography>Aquí estarán los reportes (por el momento no hay nada).</Typography>
    </Box>
  );
}
