import { Typography, Box } from "@mui/material";

export default function Footer() {
  return (
    <Box
      sx={{
        p: 2,
        textAlign: "center",
        backgroundColor: "#ffffff",
        color: "#000000",
        mt: "auto",
        width: "100%",
      }}
    >
      <Typography variant="body2">
        © 2025 Mi App - Todos los derechos reservados
      </Typography>
    </Box>
  );
}
