import { useState, useEffect } from "react";

function App() {
  
  const [characters, setCharacters] = useState([]);
  
  const [loading, setLoading] = useState(true);

  
  useEffect(() => {
    fetch("https://rickandmortyapi.com/api/character")
      .then((res) => res.json())
      .then((data) => {
        setCharacters(data.results); 
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error al cargar la API:", error);
        setLoading(false);
      });
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Personajes de Rick and Morty</h1>

      {loading ? (
        <p>Cargando...</p>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {characters.map((char) => (
            <div
              key={char.id}
              className="p-4 border rounded-lg shadow hover:shadow-lg transition"
            >
              <img src={char.image} alt={char.name} className="rounded-lg" />
              <h2 className="text-lg font-semibold mt-2">{char.name}</h2>
              <p className="text-sm text-gray-600">{char.status}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default App;
